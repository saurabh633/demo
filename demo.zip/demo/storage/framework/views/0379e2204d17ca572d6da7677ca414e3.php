
  
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New user</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('home.index')); ?>"> Back</a>
        </div>
    </div>
</div>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form id="user_form" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
  
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text" name="name" class="form-control" placeholder="Name">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Email:</strong>
                <input type="text" name="email" class="form-control" placeholder="Email">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Phone:</strong>
                <input type="text" name="phone" class="form-control" placeholder="Phone">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                <textarea class="form-control" style="height:150px" name="description" placeholder="Description"></textarea>
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Role ID:</strong>
                <select name="role_id" class="form-control">
                    <option value="1">Role 1</option>
                    <option value="2">Role 2</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Profile Image:</strong>
                <input type="file" name="profile_image" class="form-control">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" id="submitBtn"  class="btn btn-primary">Submit</button>
        </div>
    </div>
</form>
<div id="tableContainer">
    <!-- Your table content goes here -->
</div>

<?php $__env->stopSection(); ?>

    <!-- Other head content -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
    $(document).ready(function() {
        // Attach a click event handler to the submit button
        $("#user_form").click(function() {
            // Serialize the form data
            var formData = $("#user_form").serialize();

            // Send an AJAX request
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('home.store')); ?>",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    // Handle the success response
                    
                    // Assuming you have a table with an id "dataTable"
                    // Refresh the table content here
                    $("#tableContainer").load("<?php echo e(route('home.index')); ?> #dataTable");
                },
                error: function(error) {
                    // Handle the error response
                }
            });
        });
    });
</script>

<?php echo $__env->make('app.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\demo\resources\views/User/create.blade.php ENDPATH**/ ?>